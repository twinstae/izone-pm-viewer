import re
import json
import os
def get_pm_list():
    with open("pm_list.json", 'r', encoding="UTF-8") as f:
        return json.loads(f.read())
    
pm_list = get_pm_list()    

def load_html(mail_id):
    with open('mail/' + mail_id + '.html', 'r', encoding="UTF-8") as f:
        return f.read()
IMG_PTN = re.compile('img/.*?\\.(?:jpeg|jpg|png|gif)')
def remove_tag(s):
    start = re.search("""<div class="main-contents" id="mail-detail"><html><head></head><body>""", s).end()

    end = re.search("""</body></html></div>""", s).start()

    result = s[start:end]
    
    images = IMG_PTN.findall(s) or []
    for image in images:
        
        image_re = '<div class=\\"select-image.{100,400}data-id=\\".{1,8}\\" data-class=\\"images\\"></div>'
        result = re.sub(image_re, " {이미지} ", result)
        image_re2 = '<img [^>]+>'
        result = re.sub(image_re2, " {이미지} ", result)

    result = re.sub("""<span class=\\"[^>]+\\">""", "", result)
    result = re.sub(' class=\\"[^"]{1,30}\\"', "", result)
    result = result.replace("""\n""", "")
    result = result.replace("""<div>""", "<p>")
    result = result.replace("""<div dir="ltr">""", "<p>")
    result = result.replace("""<div data-favorite="false">""", "<p>")
    result = result.replace("""<div data-favorite="true">""", "<p>")
    result = result.replace("""</div>""", "</p>")
    result = result.replace("""</span>""", "")
    result = result.replace("<p>&nbsp;</p>", "\n")
    return result, images


def init():
    if not os.path.exists("mail_body_dict.json"):
        return {}
    with open("mail_body_dict.json", "r", encoding="utf-8") as f:
        return json.loads(f.read())

body_dict = init()
skip = 0
for i, pm in enumerate(pm_list):
    pm_id = pm["id"]
    try:
        raw_html = load_html(pm_id)
        try:
            body, images = remove_tag(raw_html)
        except Exception as e:
            if pm_id.startswith("i"):
                print("운영진 메일을 처리하는데 실패했습니다. 결제 취소 등의 알림은 무시하고 진행합니다.")
            else:
                print(f"{pm_id}.html 파일 처리 실패. output/mail 폴더에서 파일이 정상적인지 확인해주세요. \n 백업 뷰어 상담소: https://open.kakao.com/o/gPbArZ4c")
            print(e)
            body = raw_html
            images= []
            
        for img in images:
            if not os.path.exists(img):
                print(f"{img} 사진을 찾지 못했습니다. 사진이 누락됐을 수 있으니 확인해주세요. \n 백업 뷰어 상담소: https://open.kakao.com/o/gPbArZ4c")
        
        body_dict[pm_id] = {
            "body": body,
            "images": images
        }
        
        if i % 200 == 0:
            print(i, "개 처리 완료")
    except Exception as e:
        print(e)
        pass

with open("mail_body_dict.json", "w", encoding="utf-8") as f:
    f.write(json.dumps(body_dict, ensure_ascii=False))
    
print("[4단계] 메일 내용, 이미지 검수 완료. \n mail_body_dict.json 을 생성했습니다. \n")