from PIL import Image
import glob, os

i = 1
TMB_SIZE = 256

for infile in glob.glob("./img/mail/*/*/*"):
    if infile.endswith('_tmb.jpg'):
        continue
    i += 1
    if i % 500 == 0:
        print(i, "번 째 사진 처리 완료")
    # print(infile)
    file, ext = os.path.splitext(infile)
    
    if os.path.exists(file+'_tmb.jpg'):
        continue
    
    with Image.open(infile) as im:
        ratio = TMB_SIZE / min(*im.size)
        new_size =(int(im.size[0] * ratio), int(im.size[1] * ratio))
        # print(im.size, new_size)
        if im.mode != "RGBA":
            im.thumbnail(new_size, reducing_gap=3.0, )
            im.save(file + "_tmb.jpg", "JPEG")
        else:
            print(infile)
            rgb_im = im.convert('RGB')
            rgb_im.thumbnail(new_size)
            rgb_im.save(file + "_tmb.jpg", 'JPEG')
            
print(f"[5단계] 총 {i}개 이미지 썸네일을 생성했습니다.")