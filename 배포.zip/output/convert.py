import json
import sys

def main():
    if len(sys.argv) != 2:
        return

    f = open(sys.argv[1], "r", encoding="UTF-8")
    raw = f.read().replace("let pm_list = ", "")
    pm_data = json.loads(raw)

    for pm in pm_data:
        pm.pop("subject")
        pm.pop("preview")
        if "body" in pm:
            pm.pop("body")

    pm_list = [pm for pm in pm_data if not pm['id'].startswith("t")]
    
    m_mail_n = len([1 for pm in pm_list if pm['id'][0] == 'm'])
    i_mail_n = len([1 for pm in pm_list if pm['id'][0] == 'i'])
    print(f"아이즈원 메일 m {m_mail_n} 개") 
    print(f"운영팀 메일  i {i_mail_n} 개") 
    print(f"총 메일 {len(pm_list)} 개")
    print("[2 단계] 복제 프메 서버 인증용 pm_upload.json 을 생성했습니다. \n")
    f = open("pm_upload.json", "w", encoding="UTF-8")
    f.write(json.dumps(pm_list))
    f.close()

if __name__ == "__main__":
    main()