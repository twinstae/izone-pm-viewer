import json


def get_mail_to_num_dict():
    with open("mail_to_num_dict.json", "r") as f:
        return json.loads(f.read())


def get_pm_list():
    with open("pm_list.json", "r", encoding="UTF-8") as f:
        return json.loads(f.read())


mail_to_num_dict = get_mail_to_num_dict()
pm_list = get_pm_list()

nick_to_num_dict = {
    "장원영": 0,
    'チャン・ウォニョン': 0,
    "미야와키 사쿠라": 1,
    '宮脇咲 良': 1,
    '宮脇咲良': 1,
    "조유리": 2,
    'チョ・ユリ': 2,
    "최예나": 3,
    'チェ・イェナ': 3,
    "안유진": 4,
    "アン・ユジン": 4,
    "야부키 나코": 5,
    '矢吹奈子': 5,
    "권은비": 6,
    'クォン・ウンビ': 6,
    "강혜원": 7,
    'カン・へウォン': 7,
    "혼다 히토미": 8,
    "本田仁美": 8,
    "김채원": 9,
    'キム・チェウォン': 9,
    "김민주": 10,
    'キム・ミンジュ': 10,
    "이채연": 11,
    'イ・チェヨン': 11,
    "운영팀": 12,
}


for pm in pm_list:
    member_n = mail_to_num_dict.get(pm["id"], -1)
    member_nick = pm["member"]
    if member_nick not in nick_to_num_dict and member_n != -1:
        nick_to_num_dict[member_nick] = member_n


with open("member_name.json", "w", encoding="UTF-8") as f:

    print(nick_to_num_dict)
    f.write(json.dumps(nick_to_num_dict, ensure_ascii=False))
    print("[3단계] 멤버 별명 사전 member_name.json 생성에 성공했습니다. \n")
