import re
import json

def get_pm_list():
    with open("pm_list.json", 'r', encoding="UTF-8") as f:
        return json.loads(f.read())
    
pm_list = get_pm_list()    

def load_html(mail_id):
    with open('mail/' + mail_id + '.html', 'r', encoding="UTF-8") as f:
        return f.read()
    
def remove_tag(s):
    start = re.search("""<div class="main-contents" id="mail-detail"><html><head></head><body>""", s).end()

    end = re.search("""</body></html></div>""", s).start()

    result = s[start:end]

    result = result.replace("""&nbsp;</div>"""," ")
    result = result.replace("""</div>""","")
    result = result.replace("""&nbsp;""","")
    result = result.replace("""&nbsp;</div>""","")
    result = result.replace("\n", " ")

    return re.sub("<.+?>", "", result)

body_dict = {}

for i, pm in enumerate(pm_list):
    try:
        pm_id = pm["id"]
        raw_html = load_html(pm_id)
        try:
            body = remove_tag(raw_html)
        except:
            body = raw_html
        
        body_dict[pm_id] = body
        if i % 100 == 0:
            print(i, "개 처리 완료")
    except Exception as e:
        print(e)
        pass

with open("mail_body_dict.json", "w", encoding="utf-8") as f:
    f.write(json.dumps(body_dict, ensure_ascii=False))