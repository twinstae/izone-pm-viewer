import re
import json
import os
def get_pm_list():
    with open("pm_list.json", 'r', encoding="UTF-8") as f:
        return json.loads(f.read())
    
pm_list = get_pm_list()    

def load_html(mail_id):
    with open('mail/' + mail_id + '.html', 'r', encoding="UTF-8") as f:
        return f.read()
IMG_PTN = re.compile('img/.*?\\.(?:jpeg|jpg|png|gif)')
def remove_tag(s):
    start = re.search("""<div class="main-contents" id="mail-detail"><html><head></head><body>""", s).end()

    end = re.search("""</body></html></div>""", s).start()

    result = s[start:end]
    
    images = IMG_PTN.findall(s) or []
    for image in images:
        
        image_re = '<div class=\\"select-image.{100,400}data-id=\\".{1,8}\\" data-class=\\"images\\"></div>'
        result = re.sub(image_re, " {이미지} ", result)
        image_re2 = '<img [^>]+>'
        result = re.sub(image_re2, " {이미지} ", result)

    result = re.sub("""<span class=\\".{0,4}\\">""", "", result)
    result = re.sub("""<span class=\\".{10,30}\\">""", "", result)
    result = re.sub(' class=\\".{1,30}\\"', "", result)
    result = result.replace("""\n""", "")
    result = result.replace("""<div>""", "<p>")
    result = result.replace("""<div dir="ltr">""", "<p>")
    result = result.replace("""<div data-favorite="false">""", "<p>")
    result = result.replace("""<div data-favorite="true">""", "<p>")
    result = result.replace("""</div>""", "</p>")
    result = result.replace("""</span>""", "")
    result = result.replace("<p>&nbsp;</p>", "\n")
    return result, images


def init():
    if not os.path.exists("mail_body_dict.json"):
        return {}
    with open("mail_body_dict.json", "r", encoding="utf-8") as f:
        return json.loads(f.read())

body_dict = init()
skip = 0
for i, pm in enumerate(pm_list):
    pm_id = pm["id"]
    try:
        raw_html = load_html(pm_id)
        try:
            body, images = remove_tag(raw_html)
        except Exception as e:
            print(pm_id, "태그 제거 실패")
            print(e)
            body = raw_html
        
        body_dict[pm_id] = {
            "body": body,
            "images": images
        }
        
        if i % 200 == 0:
            print(i, "개 처리 완료")
    except Exception as e:
        print(e)
        pass

with open("mail_body_dict.json", "w", encoding="utf-8") as f:
    f.write(json.dumps(body_dict, ensure_ascii=False))