import json
PM_LIST_PATH = "pm_list.json"

def process(result):
    result = result.replace("let pm_list = ", "")
    result = result.replace("var pm_list = Array();", "").replace(");pm_list.push(", ",")
    result = result.replace("});", "}]").replace("pm_list.push(", "[")
    
    result = result.replace("笑 \ツメ", "笑 ツメ")
    result = result.replace('"이 여자한테 손 떼지 못해?"','\\"이 여자한테 손 떼지 못해?\\"')
    result = result.replace('사진찍을 때 "하트"', '사진찍을 때 하트"')
    result = result.replace('걸어 나오면서 " 배고픈', "걸어 나오면서 배고픈")
    result = result.replace('슬쩍 " 우리', '슬쩍 우리')
    result = result.replace('바로 "당연하지', "바로 당연하지")
    result = result.replace('35 ~ " 채연이', "35 ~ 채연이")
    result = result.replace('예를 들어서 " 어떡해', "예를 들어서 어떡해")
    return result

def get_new_string(file_path):
    try:
        with open(file_path, "r", encoding="UTF-16") as f:
            return process(f.read())
    except:
        with open(file_path, "r", encoding="UTF-8") as f:
            return process(f.read())

def delete_from(pm):
    del pm["image"]
    del pm["body"]
    return pm

def get_pm_list_from_json(result):
    return [delete_from(pm) for pm in json.loads(result)]  # 잘 읽히는지 테스트

def write_result_to_json(result):
    pm_list = get_pm_list_from_json(result)
    first_pm = pm_list[0]
    for key in ["id", "member", "preview", "time", "subject"]:
        assert key in first_pm
    with open(PM_LIST_PATH, "w", encoding="UTF-8") as f:
        f.write(json.dumps(pm_list))
    print("pm_list.json 생성에 성공했습니다!")


try:
    new_str = get_new_string("pm.js")
except FileNotFoundError:
    new_str = get_new_string("pm_list.js")
write_result_to_json(new_str)
