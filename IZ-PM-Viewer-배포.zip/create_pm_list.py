import json
PM_LIST_PATH = "pm_list.json"


def get_new_string(file_path):
    with open(file_path, "r", encoding="UTF-8") as f:
        result = f.read().replace("let pm_list = ", "")
        result = result.replace("var pm_list = Array();", "").replace(");pm_list.push(", ",")
        result = result.replace("});", "}]").replace("pm_list.push(", "[")
        return result


def write_new_string(result):
    pm_list = json.loads(new_str)  # 잘 읽히는지 테스트
    first_pm = pm_list[0]
    for key in ["member", "id", "time", "subject", "preview"]:
        assert key in first_pm
    with open(PM_LIST_PATH, "w", encoding="UTF-8") as f:
        f.write(result)
    print("pm_list.json 생성에 성공했습니다!")


try:
    new_str = get_new_string("pm.js")
    write_new_string(new_str)
except FileNotFoundError:
    new_str = get_new_string("pm_list.js")
    write_new_string(new_str)
