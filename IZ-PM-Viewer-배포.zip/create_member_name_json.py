import json


def get_mail_to_num_dict():
    with open("mail_to_num_dict.json", "r") as f:
        return json.loads(f.read())


def get_pm_list():
    with open("pm_list.json", "r", encoding="UTF-8") as f:
        return json.loads(f.read())


mail_to_num_dict = get_mail_to_num_dict()
pm_list = get_pm_list()

nick_to_num_dict = {
    "장원영": 0,
    "미야와키 사쿠라": 1,
    "조유리": 2,
    "최예나": 3,
    "チェ・イェナ": 3,
    "안유진": 4,
    "야부키 나코": 5,
    "宮脇咲良": 5,
    "권은비": 6,
    "강혜원": 7,
    "혼다 히토미": 8,
    "本田仁美": 8,
    "김채원": 9,
    "김민주": 10,
    "이채연": 11,
    "운영팀": 12,
}

for pm in pm_list:
    member_n = mail_to_num_dict.get(pm["id"])
    member_nick = pm["member"]
    nick_to_num_dict[member_nick] = member_n


with open("member_name.json", "w", encoding="UTF-8") as f:

    print(nick_to_num_dict)
    f.write(json.dumps(nick_to_num_dict))
    print("member_name.json 생성에 성공했습니다!")
