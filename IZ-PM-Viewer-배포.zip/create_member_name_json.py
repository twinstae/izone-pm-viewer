import json


def get_mail_to_num_dict():
    with open("mail_to_num_dict.json", "r") as f:
        return json.loads(f.read())


def get_pm_list():
    with open("pm_list.json", "r") as f:
        return json.loads(f.read())


mail_to_num_dict = get_mail_to_num_dict()
pm_list = get_pm_list()

nick_to_num_dict = {pm["member"]: mail_to_num_dict.get(pm["id"], 13) for pm in pm_list}

print(nick_to_num_dict)

with open("member_name.json", "w") as f:
    f.write(json.dumps(nick_to_num_dict))
    print("member_name.json 생성에 성공했습니다!")
