import http.server
import socketserver
import ssl

PORT = 5000

Handler = http.server.SimpleHTTPRequestHandler
Handler.extensions_map.update({
      ".js": "application/javascript",
});

httpd = socketserver.TCPServer(("localhost", PORT), Handler)
httpd.serve_forever()